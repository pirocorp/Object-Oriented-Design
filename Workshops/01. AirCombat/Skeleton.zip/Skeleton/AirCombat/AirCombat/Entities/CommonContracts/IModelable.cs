﻿namespace AirCombat.Entities.CommonContracts
{
    public interface IModelable
    {
        string Model { get; }
    }
}